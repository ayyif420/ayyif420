<?php

namespace Pterodactyl\Exceptions\Service\Schedule\Task;

use Pterodactyl\Exceptions\DisplayException;

class TaskIntervalTooLongException extends DisplayException
{
}
